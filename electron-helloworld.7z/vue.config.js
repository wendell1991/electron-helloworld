module.exports = {
  pluginOptions: {
    electronBuilder: {
      builderOptions: {
        productName: "Hello World",
      },
    },
  },
};
